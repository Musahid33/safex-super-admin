import { Card, Badge } from "@/components/ui";
import { tickets } from "@/lib/data";
export default function Section({ params }: { params: { section: string } }) {
  const s = params.section;
  return <div className="space-y-4"><h1 className="text-2xl font-semibold capitalize">{s}</h1>
    {s === "support" ? <Card className="overflow-x-auto p-0"><table className="w-full text-sm"><thead className="border-b bg-slate-50 text-left text-xs uppercase text-slate-500"><tr>{["Ticket", "Subject", "Priority", "Status", "Assigned To"].map(h => <th key={h} className="px-4 py-3">{h}</th>)}</tr></thead>
      <tbody>{tickets.map(t => <tr key={t.id} className="border-b last:border-0"><td className="px-4 py-3">{t.id}</td><td className="px-4 py-3">{t.subject}</td><td className="px-4 py-3"><Badge>{t.priority}</Badge></td><td className="px-4 py-3"><Badge>{t.status}</Badge></td><td className="px-4 py-3">{t.assignee}</td></tr>)}</tbody></table></Card>
      : <Card className="text-sm text-slate-500">Scaffold for <b>{s}</b> — build out using the same Card / table / chart components.</Card>}</div>;
}
