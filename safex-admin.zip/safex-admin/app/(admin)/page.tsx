import Link from "next/link";
import { Card, Badge, Button } from "@/components/ui";
import { RevenueChart, GrowthChart, AddonChart, PlanChart } from "@/components/charts";
import { kpis, companies, tickets, activities } from "@/lib/data";
export default function Dashboard() {
  return <div className="space-y-6">
    <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="flex gap-2"><Link href="/companies/new"><Button>Create Company</Button></Link><Link href="/companies"><Button variant="outline">View Companies</Button></Link><Link href="/settings"><Button variant="outline">Manage Plans</Button></Link></div></div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{kpis.map(([l, v, d]) => <Card key={l}><div className="text-sm text-slate-500">{l}</div><div className="mt-2 text-2xl font-semibold">{v}</div><div className={d.startsWith("-") ? "text-xs text-red-600" : "text-xs text-green-600"}>{d} vs last month</div></Card>)}</div>
    <div className="grid gap-4 lg:grid-cols-2">{[["Monthly Revenue (₹L)", <RevenueChart />], ["Company Growth", <GrowthChart />], ["Subscription Distribution", <PlanChart />], ["Add-on Revenue (₹L)", <AddonChart />]].map(([t, c]) => <Card key={t as string}><h3 className="mb-3 font-medium">{t}</h3>{c}</Card>)}</div>
    <div className="grid gap-4 lg:grid-cols-3">
      <Card><h3 className="mb-3 font-medium">Recent Activities</h3><ul className="space-y-3 text-sm text-slate-600 dark:text-slate-300">{activities.map(a => <li key={a}>• {a}</li>)}</ul></Card>
      <Card><h3 className="mb-3 font-medium">Recent Companies</h3><ul className="space-y-3 text-sm">{companies.slice(0, 4).map(c => <li key={c.id} className="flex justify-between"><Link href={`/companies/${c.id}`}>{c.name}</Link><Badge>{c.status}</Badge></li>)}</ul></Card>
      <Card><h3 className="mb-3 font-medium">Support Tickets</h3><ul className="space-y-3 text-sm">{tickets.map(t => <li key={t.id} className="flex justify-between gap-2"><span className="truncate">{t.subject}</span><Badge>{t.priority}</Badge></li>)}</ul></Card>
    </div></div>;
}
