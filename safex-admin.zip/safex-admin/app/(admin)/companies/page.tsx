"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { useReactTable, getCoreRowModel, getFilteredRowModel, getPaginationRowModel, flexRender, createColumnHelper } from "@tanstack/react-table";
import { Plus } from "lucide-react";
import { Card, Badge, Button, inputCls } from "@/components/ui";
import { companies, Company } from "@/lib/data";
const h = createColumnHelper<Company>();
export default function Companies() {
  const [q, setQ] = useState(""), [status, setStatus] = useState(""), [plan, setPlan] = useState("");
  const data = useMemo(() => companies.filter(c => (!status || c.status === status) && (!plan || c.plan === plan) && c.name.toLowerCase().includes(q.toLowerCase())), [q, status, plan]);
  const columns = useMemo(() => [
    h.display({ id: "logo", header: "Logo", cell: i => <span className="grid h-8 w-8 place-items-center rounded-lg bg-blue-50 text-xs font-semibold text-primary">{i.row.original.name[0]}</span> }),
    h.accessor("name", { header: "Company", cell: i => <Link className="font-medium hover:text-primary" href={`/companies/${i.row.original.id}`}>{i.getValue()}</Link> }),
    h.accessor("sub", { header: "Subdomain", cell: i => `${i.getValue()}.safex.app` }),
    h.accessor("admin", { header: "Admin" }), h.accessor("plan", { header: "Plan" }),
    h.accessor("addons", { header: "Add-ons", cell: i => i.getValue().length || "—" }),
    h.accessor("users", { header: "Users" }), h.accessor("locations", { header: "Locations" }), h.accessor("expiry", { header: "Expiry" }),
    h.accessor("status", { header: "Status", cell: i => <Badge>{i.getValue()}</Badge> }),
    h.display({ id: "a", header: "Actions", cell: i => <Link className="text-primary" href={`/companies/${i.row.original.id}`}>Manage</Link> })], []);
  const t = useReactTable({ data, columns, getCoreRowModel: getCoreRowModel(), getFilteredRowModel: getFilteredRowModel(), getPaginationRowModel: getPaginationRowModel(), initialState: { pagination: { pageSize: 10 } } });
  return <div className="space-y-4">
    <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl font-semibold">Companies</h1><Link href="/companies/new"><Button><Plus size={16} />Add Company</Button></Link></div>
    <div className="flex flex-wrap gap-3"><input className={inputCls + " max-w-xs"} placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
      <select className={inputCls + " w-40"} value={status} onChange={e => setStatus(e.target.value)}><option value="">All status</option><option>Active</option><option>Trial</option><option>Suspended</option></select>
      <select className={inputCls + " w-40"} value={plan} onChange={e => setPlan(e.target.value)}><option value="">All plans</option><option>Starter</option><option>Pro</option><option>Enterprise</option></select>
      <select className={inputCls + " w-40"}><option>All industries</option><option>Mining</option><option>Steel</option><option>Logistics</option></select></div>
    <Card className="overflow-x-auto p-0"><table className="w-full text-sm"><thead className="border-b bg-slate-50 text-left text-xs uppercase text-slate-500 dark:bg-slate-800">{t.getHeaderGroups().map(g => <tr key={g.id}>{g.headers.map(x => <th key={x.id} className="px-4 py-3 font-medium">{flexRender(x.column.columnDef.header, x.getContext())}</th>)}</tr>)}</thead>
      <tbody>{t.getRowModel().rows.map(r => <tr key={r.id} className="border-b last:border-0 hover:bg-slate-50 dark:hover:bg-slate-800/50">{r.getVisibleCells().map(c => <td key={c.id} className="whitespace-nowrap px-4 py-3">{flexRender(c.column.columnDef.cell, c.getContext())}</td>)}</tr>)}</tbody></table></Card>
    <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => t.previousPage()} disabled={!t.getCanPreviousPage()}>Prev</Button><Button variant="outline" onClick={() => t.nextPage()} disabled={!t.getCanNextPage()}>Next</Button></div></div>;
}
