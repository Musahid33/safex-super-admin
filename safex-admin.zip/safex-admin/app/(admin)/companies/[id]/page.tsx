"use client";
import { useState } from "react";
import { useParams } from "next/navigation";
import clsx from "clsx";
import { Card, Badge, Button, Toggle } from "@/components/ui";
import { companies, baseFeatures, addonList, activities } from "@/lib/data";
const tabs = ["Overview", "Subscription", "Features", "Limits", "Domains", "Activity"];
const Row = ({ k, v }: { k: string; v: React.ReactNode }) => <div className="flex justify-between border-b py-2 text-sm last:border-0"><span className="text-slate-500">{k}</span><span>{v}</span></div>;
const Bar = ({ k, used, max }: { k: string; used: number; max: number }) => <div className="space-y-1.5"><div className="flex justify-between text-sm"><span>{k}</span><span className="text-slate-500">{used} / {max}</span></div><div className="h-2 rounded-full bg-slate-100"><div className={clsx("h-2 rounded-full", used / max > 0.9 ? "bg-red-500" : used / max > 0.75 ? "bg-orange-500" : "bg-primary")} style={{ width: `${Math.min(100, used / max * 100)}%` }} /></div></div>;
export default function Detail() {
  const { id } = useParams<{ id: string }>(); const c = companies.find(x => x.id === id) ?? companies[0]; const [t, setT] = useState("Overview");
  return <div className="space-y-6">
    <div className="flex flex-wrap items-center gap-3"><h1 className="text-2xl font-semibold">{c.name}</h1><Badge>{c.status}</Badge></div>
    <div className="flex gap-1 overflow-x-auto border-b">{tabs.map(x => <button key={x} onClick={() => setT(x)} className={clsx("whitespace-nowrap border-b-2 px-4 py-2 text-sm", t === x ? "border-primary text-primary" : "border-transparent text-slate-500")}>{x}</button>)}</div>
    {t === "Overview" && <div className="grid gap-4 lg:grid-cols-2"><Card><h3 className="mb-2 font-medium">Company</h3><Row k="Subdomain" v={`${c.sub}.safex.app`} /><Row k="Plan" v={c.plan} /><Row k="Locations" v={c.locations} /></Card>
      <Card><h3 className="mb-2 font-medium">Admin</h3><Row k="Name" v={c.admin} /><Row k="Email" v={`${c.admin.split(" ").pop()?.toLowerCase()}@${c.sub}.com`} /></Card>
      <Card className="space-y-4"><h3 className="font-medium">Storage Usage</h3><Bar k="Storage (GB)" used={38} max={50} /></Card>
      <Card><h3 className="mb-3 font-medium">Quick Actions</h3><div className="flex flex-wrap gap-2"><Button variant="outline">Suspend</Button><Button variant="outline">Reset Admin Password</Button><Button>Upgrade Plan</Button></div></Card></div>}
    {t === "Subscription" && <Card><Row k="Plan" v={c.plan} /><Row k="Expiry" v={c.expiry} /><Row k="Payment Status" v={<Badge>Active</Badge>} /><div className="mt-4 flex gap-2"><Button>Renew</Button><Button variant="outline">Upgrade</Button></div><h3 className="mb-2 mt-6 font-medium">Billing History</h3><Row k="Nov 2026" v="₹49,999 · Paid" /><Row k="Oct 2026" v="₹49,999 · Paid" /></Card>}
    {t === "Features" && <div className="grid gap-4 lg:grid-cols-2"><Card><h3 className="mb-1 font-medium">Base Features</h3><p className="mb-3 text-xs text-slate-500">Fixed — cannot be disabled.</p><div className="grid grid-cols-2 gap-2 text-sm">{baseFeatures.map(f => <div key={f} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 dark:bg-slate-800">{f}<Toggle on locked /></div>)}</div></Card>
      <Card><h3 className="mb-3 font-medium">Premium Add-ons</h3>{addonList.map(a => { const on = c.addons.some(x => a.name.startsWith(x)); return <div key={a.name} className="flex items-center justify-between border-b py-3 text-sm last:border-0"><div><div className="font-medium">{a.name}</div><div className="text-xs text-slate-500">{a.price}</div></div><div className="flex items-center gap-3"><Badge>{on ? "Active" : "Low"}</Badge><Toggle on={on} /></div></div>; })}</Card></div>}
    {t === "Limits" && <Card className="max-w-xl space-y-4"><Bar k="Users" used={c.users} max={Math.round(c.users * 1.2)} /><Bar k="Employees" used={1800} max={2500} /><Bar k="Locations" used={c.locations} max={c.locations + 2} /><Bar k="Storage (GB)" used={38} max={50} /><Bar k="API Calls (k)" used={720} max={1000} /></Card>}
    {t === "Domains" && <Card className="max-w-xl"><Row k="Default Domain" v={`${c.sub}.safex.app`} /><Row k="Custom Domain" v="Managed by Super Admin only" /><Row k="SSL Status" v={<Badge>Active</Badge>} /></Card>}
    {t === "Activity" && <Card><ul className="space-y-3 text-sm">{activities.map(a => <li key={a}>• {a}</li>)}</ul></Card>}
  </div>;
}
