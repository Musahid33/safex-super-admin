"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import clsx from "clsx";
import { Card, Button, inputCls, Toggle } from "@/components/ui";
const steps = ["Company", "Admin", "Subscription", "Add-ons", "Limits", "Review"];
type F = { name: string; short: string; industry: string; email: string; phone: string; address: string; adminName: string; adminEmail: string; adminMobile: string; password: string; plan: string; billing: string; start: string; expiry: string; users: number; employees: number; locations: number; storage: number };
const gen = () => Math.random().toString(36).slice(2, 6) + "-" + Math.random().toString(36).slice(2, 8).toUpperCase() + "!";
const Field = ({ label, children }: { label: string; children: React.ReactNode }) => <label className="block space-y-1.5 text-sm"><span className="font-medium">{label}</span>{children}</label>;
export default function NewCompany() {
  const [s, setS] = useState(0); const [addons, setAddons] = useState<string[]>([]);
  const { register, watch, setValue, handleSubmit } = useForm<F>({ defaultValues: { password: gen(), billing: "Monthly", plan: "Pro", users: 100, employees: 500, locations: 5, storage: 50 } });
  const v = watch(); const sub = (v.short || v.name || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const r = (k: keyof F, o = {}) => <input className={inputCls} {...register(k, o)} />;
  return <form onSubmit={handleSubmit(d => alert("Published (UI only)\n" + JSON.stringify({ ...d, addons }, null, 2)))} className="mx-auto max-w-3xl space-y-6">
    <h1 className="text-2xl font-semibold">Create Company</h1>
    <ol className="flex gap-2 overflow-x-auto">{steps.map((x, i) => <li key={x} className={clsx("flex items-center gap-2 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium", i === s ? "bg-primary text-white" : i < s ? "bg-green-50 text-green-700" : "bg-slate-100 text-slate-500")}>{i + 1}. {x}</li>)}</ol>
    <Card className="grid gap-4 sm:grid-cols-2">
      {s === 0 && <><Field label="Company Name">{r("name", { required: true })}</Field><Field label="Short Name">{r("short")}</Field>
        <Field label="Industry"><select className={inputCls} {...register("industry")}><option>Mining</option><option>Steel</option><option>Construction</option><option>Logistics</option></select></Field>
        <Field label="Company Logo"><input type="file" className={inputCls} /></Field>
        <Field label="Subdomain (auto)"><input className={inputCls + " bg-slate-50"} readOnly value={sub ? `${sub}.safex.app` : ""} /></Field><Field label="Company Email">{r("email")}</Field><Field label="Company Phone">{r("phone")}</Field>
        <div className="sm:col-span-2"><Field label="Address"><textarea className={inputCls} rows={3} {...register("address")} /></Field></div></>}
      {s === 1 && <><Field label="Admin Name">{r("adminName")}</Field><Field label="Admin Email">{r("adminEmail")}</Field><Field label="Admin Mobile">{r("adminMobile")}</Field>
        <Field label="Temporary Password"><div className="flex gap-2"><input className={inputCls} readOnly value={v.password} /><Button type="button" variant="outline" onClick={() => setValue("password", gen())}>New</Button></div></Field></>}
      {s === 2 && <><Field label="Plan"><select className={inputCls} {...register("plan")}><option>Starter</option><option>Pro</option><option>Enterprise</option></select></Field>
        <Field label="Billing"><select className={inputCls} {...register("billing")}><option>Monthly</option><option>Yearly</option></select></Field>
        <Field label="Start Date"><input type="date" className={inputCls} {...register("start")} /></Field><Field label="Expiry Date"><input type="date" className={inputCls} {...register("expiry")} /></Field></>}
      {s === 3 && <div className="space-y-3 sm:col-span-2">{["Asset Management", "Salary Slip", "Email Integration"].map(a => <button type="button" key={a} onClick={() => setAddons(x => x.includes(a) ? x.filter(i => i !== a) : [...x, a])} className="flex w-full items-center justify-between rounded-xl border p-4 text-sm"><span>{a}</span><Toggle on={addons.includes(a)} /></button>)}</div>}
      {s === 4 && <><Field label="Maximum Users">{r("users")}</Field><Field label="Maximum Employees">{r("employees")}</Field><Field label="Maximum Locations">{r("locations")}</Field><Field label="Storage (GB)">{r("storage")}</Field></>}
      {s === 5 && <pre className="overflow-auto rounded-xl bg-slate-50 p-4 text-xs sm:col-span-2 dark:bg-slate-800">{JSON.stringify({ ...v, subdomain: sub && sub + ".safex.app", addons }, null, 2)}</pre>}
    </Card>
    <div className="flex flex-wrap justify-between gap-2"><Button type="button" variant="outline" disabled={!s} onClick={() => setS(s - 1)}>Back</Button>
      <div className="flex gap-2">{s < 5 ? <Button type="button" onClick={() => setS(s + 1)}>Next</Button> : <><Button type="button" variant="outline">Save Draft</Button><Button type="button" variant="outline">Preview</Button><Button type="submit">Publish Company</Button></>}</div></div></form>;
}
