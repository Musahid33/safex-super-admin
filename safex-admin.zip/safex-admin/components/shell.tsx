"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Building2, CreditCard, BarChart3, LifeBuoy, Settings, User, LogOut, Search, Bell, Moon, Menu } from "lucide-react";
import clsx from "clsx";
import { useState } from "react";
const nav = [["/","Dashboard",LayoutDashboard],["/companies","Company Management",Building2],["/subscription","Subscription",CreditCard],["/analytics","Analytics",BarChart3],["/support","Support",LifeBuoy],["/settings","Settings",Settings],["/profile","My Profile",User],["/logout","Logout",LogOut]] as const;
export function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname(); const [open, setOpen] = useState(false);
  return <div className="min-h-screen">
    <aside className={clsx("fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 p-4 text-slate-300 transition lg:translate-x-0", open ? "translate-x-0" : "-translate-x-full")}>
      <div className="mb-8 flex items-center gap-2 px-2 text-lg font-semibold text-white"><span className="grid h-8 w-8 place-items-center rounded-lg bg-primary">S</span>SAFEX</div>
      <nav className="space-y-1">{nav.map(([href, label, Icon]) => { const active = href === "/" ? path === "/" : path.startsWith(href); return <Link key={href} href={href} onClick={() => setOpen(false)} className={clsx("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm", active ? "bg-primary text-white" : "hover:bg-slate-800")}><Icon size={18} />{label}</Link>; })}</nav>
    </aside>
    <div className="lg:pl-64">
      <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90 lg:px-8">
        <button className="lg:hidden" onClick={() => setOpen(!open)}><Menu /></button>
        <div className="relative max-w-md flex-1"><Search size={16} className="absolute left-3 top-2.5 text-slate-400" /><input placeholder="Search companies, tickets…" className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm outline-none dark:border-slate-700 dark:bg-slate-800" /></div>
        <button onClick={() => document.documentElement.classList.toggle("dark")} aria-label="Theme"><Moon size={18} /></button>
        <button className="relative"><Bell size={18} /><span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-red-500" /></button>
        <div className="hidden text-right text-xs sm:block"><div className="font-medium">Super Admin</div><div className="text-slate-500">admin@safex.app</div></div>
        <div className="grid h-9 w-9 place-items-center rounded-full bg-primary text-sm font-medium text-white">SA</div>
      </header>
      <main className="p-4 lg:p-8">{children}</main>
    </div></div>;
}
