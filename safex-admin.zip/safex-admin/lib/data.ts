export type Company = { id: string; name: string; sub: string; admin: string; plan: "Starter"|"Pro"|"Enterprise"; addons: string[]; users: number; locations: number; expiry: string; status: "Active"|"Trial"|"Suspended" };
export const companies: Company[] = [
 {id:"1",name:"Emveess Infraventures",sub:"emveess",admin:"Musahid",plan:"Enterprise",addons:["Asset","Email"],users:240,locations:6,expiry:"2027-03-31",status:"Active"},
 {id:"2",name:"Tata Steel West Bokaro",sub:"tsl-wb",admin:"R. Singh",plan:"Enterprise",addons:["Asset","Salary Slip","Email"],users:1200,locations:12,expiry:"2027-01-15",status:"Active"},
 {id:"3",name:"Jharkhand Mining Co.",sub:"jmc",admin:"A. Kumar",plan:"Pro",addons:["Email"],users:85,locations:3,expiry:"2026-12-10",status:"Trial"},
 {id:"4",name:"Ramgarh Logistics",sub:"ramlog",admin:"S. Devi",plan:"Starter",addons:[],users:22,locations:1,expiry:"2026-11-02",status:"Suspended"},
 {id:"5",name:"Bokaro Fabricators",sub:"bokfab",admin:"P. Sharma",plan:"Pro",addons:["Asset"],users:140,locations:4,expiry:"2027-06-30",status:"Active"}];
export const kpis = [["Total Companies","128","+8%"],["Active Companies","104","+5%"],["Trial Companies","16","+12%"],["Suspended","8","-2%"],["Monthly Revenue","₹18.4L","+14%"],["Total Employees","42,310","+6%"],["Active Users","9,874","+9%"],["Storage Usage","1.8 TB","+11%"]];
const m=["Jun","Jul","Aug","Sep","Oct","Nov"];
export const revenue = m.map((x,i)=>({m:x,revenue:[9,11,12.5,14,16,18.4][i],addons:[1,1.4,1.9,2.2,2.8,3.4][i],companies:[70,82,95,108,119,128][i]}));
export const plans = [{name:"Starter",value:48},{name:"Pro",value:52},{name:"Enterprise",value:28}];
export const tickets = [{id:"T-1042",subject:"SSL not issuing for custom domain",priority:"High",status:"Open",assignee:"Anita"},{id:"T-1041",subject:"Bulk employee import failing",priority:"Critical",status:"In Progress",assignee:"Rohit"},{id:"T-1039",subject:"Invoice GST correction",priority:"Low",status:"Resolved",assignee:"Anita"}];
export const activities = ["Tata Steel West Bokaro upgraded to Enterprise","Jharkhand Mining Co. trial started","Ramgarh Logistics suspended (payment overdue)","Asset Management enabled for Bokaro Fabricators"];
export const baseFeatures = ["Dashboard","Employees","Safety Passport","Near Miss","Hazard","Safety Observation","Training","TBT","Incident","Audit","CAPA","Reports","CSMS Drive","Emergency Contacts","Notice Board"];
export const addonList = [{name:"Asset Management",price:"₹4,999/mo"},{name:"Salary Slip",price:"₹2,999/mo"},{name:"Email Integration",price:"₹1,999/mo"}];
