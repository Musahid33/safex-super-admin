import { notFound } from "next/navigation";

import { CompanyDetail } from "@/components/companies/company-detail";
import { companies } from "@/lib/data";

export function generateStaticParams() {
  return companies.map((company) => ({ id: company.id }));
}

export default async function CompanyDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ tab?: string; edit?: string }>;
}) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const company = companies.find((item) => item.id === id);

  if (!company) notFound();

  return (
    <CompanyDetail
      company={company}
      defaultTab={query.tab ?? "overview"}
      openEdit={query.edit === "1"}
    />
  );
}
