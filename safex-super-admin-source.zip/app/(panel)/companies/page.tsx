import { Plus } from "lucide-react";
import Link from "next/link";

import { CompaniesTable } from "@/components/companies/companies-table";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";

export default function CompaniesPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Company Management"
        description="Provision, govern and monitor every isolated tenant on the SAFEX platform."
        meta={
          <span className="rounded-full border border-border bg-muted/60 px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
            214 tenants
          </span>
        }
        actions={
          <Button size="sm" asChild>
            <Link href="/companies/new">
              <Plus className="size-3.5" />
              Create Company
            </Link>
          </Button>
        }
      />
      <CompaniesTable />
    </div>
  );
}
