import { CreateCompanyWizard } from "@/components/companies/create-company-wizard";

export default function NewCompanyPage() {
  return <CreateCompanyWizard />;
}
